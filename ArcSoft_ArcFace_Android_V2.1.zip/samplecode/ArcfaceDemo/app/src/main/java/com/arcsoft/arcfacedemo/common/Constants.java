package com.arcsoft.arcfacedemo.common;

public class Constants {
    public static final String APP_ID = "官网获取的APP_ID";
    public static final String SDK_KEY = "官网获取的SDK_KEY";
}
